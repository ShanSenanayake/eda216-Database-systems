<?php
	$host = "puccini.cs.lth.se";
	$userName = "xxx";
	$password = "yyy";
	$database = "xxx";
?>
